USE master;
GO

IF DB_ID('FloraDB') IS NOT NULL
    DROP DATABASE FloraDB;
GO

CREATE DATABASE FloraDB;
GO

USE FloraDB;
GO

CREATE TABLE FlowersPlants (
    FlowerID INT IDENTITY(1,1) PRIMARY KEY,
    FlowerName NVARCHAR(50) NOT NULL,
    PlantType NVARCHAR(50),
    Color NVARCHAR(50),
    Price DECIMAL(10,2) CHECK (Price >= 0),
    InStock INT DEFAULT 0,
    CreatedDate DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE Suppliers (
    SupplierID INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName NVARCHAR(50) NOT NULL,
    ContactName NVARCHAR(100),
    Phone NVARCHAR(20),
    Email NVARCHAR(100) UNIQUE,
    Address NVARCHAR(200),
);
GO

CREATE TABLE Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate DATETIME DEFAULT GETDATE(),
    SupplierID INT,
    FlowerID INT,
    Quantity INT CHECK (Quantity > 0),
    TotalPrice DECIMAL(15, 2) CHECK (TotalPrice >= 0),
    Status NVARCHAR(20) DEFAULT 'Processing' CHECK (Status IN ('Processing', 'Shipped', 'Delivered', 'Canselled')),
    CONSTRAINT FK_Orders_SupplierID FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
    CONSTRAINT FK_Orders_FlowerID FOREIGN KEY (FlowerID) REFERENCES FlowersPlants(FlowerID),
);
GO

CREATE TABLE Deliveries (
    DeliveryID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    DeliveryDate DATETIME NULL,
    DeliveryStatus NVARCHAR(20) DEFAULT 'Pending' CHECK (DeliveryStatus IN ('Pending','In Transit','Delivered','Failed')),
    DeliveryAddres NVARCHAR(200), 
    CONSTRAINT FK_Deliveries_OrderID FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);
GO

SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE';


